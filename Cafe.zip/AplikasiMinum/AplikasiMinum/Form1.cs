using System.Globalization;

namespace AplikasiMinum
{
    public partial class Form1 : Form
    {
        decimal totalPrice = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Espresso - Rp10.000");
            comboBox1.Items.Add("Latte - Rp15.000");
            comboBox1.Items.Add("Cappuccino - Rp12.000");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string order = comboBox1.Text;
            decimal sizePrice = 0;
            decimal toppingPrice = 0;
            if (checkBox1.Checked)
            {
                toppingPrice += 3000;
            }
            if (checkBox2.Checked)
            {
                toppingPrice += 3500;
            }
            if (checkBox3.Checked)
            {
                toppingPrice += 2500;
            }
            if (checkBox4.Checked)
            {
                toppingPrice += 1000;
            }
            if (checkBox5.Checked)
            {
                toppingPrice += 1500;
            }
            if (checkBox6.Checked)
            {
                toppingPrice += 2000;
            }
            if (radioButton1.Checked)
            {
                sizePrice = 0;
            }
            else if (radioButton2.Checked)
            {
                sizePrice = 3000;
            }
            int startIdx = order.LastIndexOf("Rp") + 2;
            string menuPriceStr = order.Substring(startIdx).Replace(".", "");

            decimal menuPrice;
            if (!decimal.TryParse(menuPriceStr, out menuPrice))
            {
                MessageBox.Show("Harga tidak valid.");
                return;
            }

            totalPrice = menuPrice + sizePrice + toppingPrice;
            textBox1.Text = "Total Harga : Rp" + totalPrice.ToString("N0");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}